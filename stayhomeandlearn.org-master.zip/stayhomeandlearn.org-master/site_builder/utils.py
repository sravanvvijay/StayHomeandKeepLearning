from pathlib import Path

SRC_DIR = Path(__file__).parent
TEMPLATE_DIR = SRC_DIR / "template"
SITE_DIR = SRC_DIR / "site"
DATA_DIR = SRC_DIR / "data"

IGNORED_FILES = ["template.html", ".DS_Store"]
INVALIDATIONS = ["/index.html", "/css/style.css"]

LISTS_MAPPING = {
    "FreeCourses": "&#128218; FreeCourses",
    "YoutubeSource": "&#128187; YoutubeSource"
}

CONTENT_TYPE_MAPPING = {
    ".css": "text/css",
    ".html": "text/html",
    ".png": "image/png",
    ".xml": "text/xml",
}
